dict = {
    'name': 'name',
    'pwd': '123',
    'lock': '0'
}

print(dict)